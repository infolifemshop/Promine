# MindAI Pro — Android Referans Uygulaması

Bu klasör, `MindAI_Pro_Birlesik_Spesifikasyon.md` dosyasındaki spesifikasyona dayanan
çalışır durumdaki bir Android (Kotlin + Jetpack Compose) proje iskeletidir.

## Nasıl açılır

1. Android Studio (Koala/2024.1 veya üzeri) ile bu klasörü **"Open"** ile açın.
2. Android Studio, `gradle/wrapper/gradle-wrapper.properties` dosyasını görüp eksik
   `gradle-wrapper.jar` dosyasını otomatik indirecektir (bu proje internet erişimi
   olmayan bir ortamda hazırlandığı için jar dosyası önceden indirilememiştir —
   ilk açılışta Android Studio bunu kendisi tamamlar).
3. Gradle sync tamamlandıktan sonra `app` modülünü bir emülatör veya cihazda çalıştırın.

## Doğrulama notu (önemli)

Bu proje, internet erişimi ve Android SDK/Gradle çalıştırma imkânı olmayan bir ortamda
yazıldı. Bu yüzden gerçek bir `./gradlew build` ile derleme testi yapılamadı.
Bunun yerine şu statik kontroller elle yapıldı:
- Kullanılan her `R.string.*` referansının `strings.xml`de tanımlı olduğu satır satır
  doğrulandı (47 Kotlin dosyasının tamamı tarandı).
- Tüm XML kaynak dosyaları (`AndroidManifest.xml`, `strings.xml`, `colors.xml`,
  `themes.xml`, ikon/locale config dosyaları) XML olarak geçerliliği teyit edildi.
- Room entity/DAO/Converter eşleşmeleri (enum ↔ TypeConverter, tablo ↔ `@Database`
  listesi) tek tek karşılaştırıldı.
- Compose ekranlarında yerel değişken adlarının `items()` gibi import edilen
  fonksiyon adlarıyla çakışmadığı kontrol edildi (bir tanesi bulunup düzeltildi —
  `StoklarScreen`).
- Kullanılan Material ikonlarının (`AutoAwesome`, `Add`, `ChevronRight`, `Home`,
  `CheckCircle`, `AccountBalance`, `AccountTree`, `MoreHoriz`) standart ve kesin
  var olan simgeler olduğu teyit edildi (belirsiz olan `Hub` ikonu `AccountTree`
  ile değiştirildi).
- Bir gerçek mantık hatası bulunup düzeltildi: AI önerisi onaylanınca oluşturulan
  cari kayıtlar (`aiTarafindanMi = true`) Cari Hesaplar ekranında yanlışlıkla
  filtreleniyordu; bu filtre kaldırıldı (`ContactsViewModel`).

Yine de gerçek bir Gradle/Kotlin derleyicisi çalıştırılmadığı için, çok ince tip
uyumsuzlukları (örn. bir Compose API'sinin tam imzasındaki küçük bir fark) ihtimal
dahilinde kalır. Android Studio'da ilk "Build" sonrası çıkabilecek hatalar,
genellikle import veya parametre adı düzeltmesi gibi küçük ve hızlı çözülebilir
hatalar olur; mimari/veri akışı düzeyinde bir sorun beklenmiyor.

## Neler gerçek, neler referans/placeholder

**Gerçek ve çalışır durumda:**
- Room veritabanı: Cari, Finansal Kayıt (gelir/gider/tahsilat/ödeme), Görev,
  Zihin Haritası (node/kenar), **Çek, Senet, Banka Hesabı + Hareketi, Kasa Hareketi,
  Fatura, Stok Kartı** tabloları — hepsi DAO + Repository ile bağlı.
- Kural tabanlı Türkçe doğal dil analiz motoru (`TurkishRuleBasedAnalysisService`) —
  metinden para tutarı (rakam + yazıyla), kişi adı, durum (bekleniyor/tamamlandı/
  belirsiz) ve görev çıkarır; demo senaryosunu (spesifikasyon Bölüm 28) işleyebilir.
- AI önerisi → onay/red akışı: hiçbir kayıt kullanıcı onayı olmadan kesinleşmez.
- Ekranlar: Ana Sayfa, AI Giriş/Analiz/Sonuç, Zihin Haritası (Canvas tabanlı basit
  graf çizimi), Cari Hesaplar (bakiye hesaplı), Görevler, **Çekler, Senetler,
  Bankalar, Kasa, Faturalar, Stoklar** (her biri liste + "ekle" diyaloğuyla gerçek
  CRUD-lite işlevsellik), Daha Fazla (artık her modüle gerçekten yönlendiriyor),
  Ayarlar.
- Tamamen Türkçe, merkezi `strings.xml` kaynak sistemi — kod içinde sabit metin yok.

**Referans/placeholder (bilinçli olarak sadeleştirilmiş kısımlar):**
- `AIAnalysisService` arayüzünün arkasına gerçek bir LLM API çağrısı (örn. Anthropic
  Claude API) bağlanmadı; bu, `TurkishRuleBasedAnalysisService`'in yerine yeni bir
  sınıf yazıp `MindAIApplication.aiService`'te değiştirmek kadar basittir.
- Çek/Senet/Fatura/Stok formlarında vade tarihi seçici (date picker) yok; bu
  alanlar veri modelinde mevcut (`vadeTarihi: Long?`) ama giriş ekranında henüz
  bağlanmadı — basit bir `DatePickerDialog` eklenerek tamamlanabilir.
- Banka hesap hareketi ekleme ekranı yok (yalnızca hesap oluşturma); repository
  katmanında `addBankTransaction` metodu hazır, `BankalarScreen`e bir "hareket ekle"
  diyaloğu eklenerek kolayca bağlanabilir.
- Gelirler/Giderler/Tahsilatlar/Ödemeler için kendi ayrı liste ekranları yok; bu
  veriler şu an Cari Hesaplar ekranında kişi bazlı bakiye olarak görünüyor.
  `CeklerScreen` + `CekViewModel` ikilisi bu modüller için doğrudan şablon olarak
  kopyalanabilir.
- Çoklu işletme desteği, cloud sync, gerçek dışa aktarma (CSV/Excel/PDF) uygulanmadı.

## Mimari

```
data/local        -> Room entity + DAO + AppDatabase + Converters
data/repository   -> AppRepository (tek giriş noktası; AI önerisi/onay mantığı burada)
domain/model      -> Enum'lar (durum, öncelik, node tipi, çek/senet/fatura durumu...)
domain/ai         -> AIAnalysisService arayüzü + Türkçe kural tabanlı implementasyon
ui/<ekran>        -> Her ekran için Composable + ViewModel çifti
ui/modules        -> Çek/Senet/Banka/Kasa/Fatura/Stok (aynı desen, tek dosyada VM+ekran)
ui/navigation     -> NavHost + alt navigasyon + Daha Fazla modül listesi
```

Bağımlılık enjeksiyonu Hilt yerine `MindAIApplication` + `MindAIViewModelFactory` ile
manuel yapılır (bu ortamda ek derleyici eklentisi indirmeden basit tutmak için).

## Yerelleştirme kuralı

Tüm kullanıcı arayüzü metinleri `app/src/main/res/values/strings.xml` üzerinden gelir.
Yeni bir ekran eklerken asla `Text("...")` içine sabit metin yazılmaz;
`stringResource(R.string.xxx)` kullanılır ve karşılığı `strings.xml`e eklenir.

## Bilinen düzeltme geçmişi

- **v1.1** — Para tutarı ayrıştırıcısı yalnızca "250.000 TL" (noktalı gruplu) veya
  "80 bin TL" (bin/milyon ekli) formatlarını tanıyordu; düz rakamlar ("500 TL",
  "5000 lira") hiç yakalanmıyor, bu yüzden analiz "0 para hareketi" ile boş
  dönüyordu. Ayrıca kişi ismi çıkarımı Türkçe hal eklerini isme yapıştırıyordu
  (örn. doğrusu sadece "Mehmet" olması gerekirken "Mehmet'ten" dönüyordu). İkisi
  de `TurkishRuleBasedAnalysisService.kt` içinde düzeltildi.
- Bilinmesi gereken temel sınırlama: bu kural tabanlı ayrıştırıcı yalnızca belirli
  Türkçe kalıpları (para birimi ifadeleri, "abi/abla" ekli isimler, belirli görev
  fiilleri) tanır. Bu kalıplara uymayan bir metin girildiğinde "0 kişi, 0 para
  hareketi, 0 görev tespit edildi" çıktısı **hatalı değil, beklenen** davranıştır —
  gerçek bir dil modeli değildir.

## APK'yı Termux dışında derlemenin yolları

### 1. GitHub Actions ile bulutta derleme (PC/Android Studio gerekmez, telefon yeterli)

Bu depoya `.github/workflows/build-apk.yml` eklendi — projeyi GitHub'a yükleyip
Actions sekmesinden tetiklediğinde APK, GitHub'ın kendi sunucularında derlenir
ve indirilebilir bir dosya olarak sana sunulur.

**Adımlar (telefon tarayıcısından da yapılabilir):**
1. [github.com](https://github.com) üzerinde ücretsiz bir hesap aç (yoksa).
2. Yeni bir **boş** repo oluştur (örn. `mindai-pro`), "Add a README" işaretini kapalı bırak.
3. Bu proje klasörünü (zip içeriğini) o repoya yükle:
   - Telefonda Termux açıksa: `git init && git remote add origin <repo-url> && git add . && git commit -m "ilk yükleme" && git push -u origin main`
   - Ya da GitHub'ın web arayüzünden "Add file → Upload files" ile dosyaları sürükle-bırak yükle (zip'i önce açman gerekir; GitHub web arayüzü zip yüklemeyi kabul etmez, dosya/klasör yükler).
4. Repo sayfasında **Actions** sekmesine git. "Android APK Derle" workflow'unu göreceksin.
5. Otomatik tetiklenmediyse **Run workflow** butonuna bas.
6. Derleme bitince (~3-8 dakika) çalışan işin sayfasında **Artifacts** bölümünden
   `MindAIPro-debug-apk` dosyasını indir — içinde `.apk` dosyası olacak.
7. APK'yı telefona indirip kurabilirsin (bilinmeyen kaynaklardan yükleme izni gerekebilir).

Bu yöntem, Termux'taki gibi paket/derleyici kurulum sorunlarıyla uğraşmaz çünkü
GitHub'ın hazır Ubuntu sunucusunda tam donanımlı bir Android SDK zaten kurulu gelir.

### 2. Android Studio (bir PC/Mac/Linux bilgisayara erişimin varsa — en sağlam yol)

[developer.android.com/studio](https://developer.android.com/studio) adresinden
indir, bu proje klasörünü **Open** ile aç, Gradle sync bitince
**Build → Build Bundle(s)/APK(s) → Build APK(s)**.

### 3. Bulut geliştirme ortamları (tarayıcıdan, PC gerekmeden Android Studio kalitesinde)

- **Gitpod** veya **GitHub Codespaces**: Depoyu bu ortamlardan biriyle açarsan
  tam bir Linux sunucusu (internet erişimli) tarayıcı üzerinden çalışır; içinde
  `./gradlew assembleDebug` komutunu doğrudan çalıştırabilirsin. Termux'un
  aksine bu ortamların interneti ve önceden kurulu build araçları vardır.

### Neden Termux'ta zorlanmış olabilirsin

Termux'ta Android SDK/Gradle/KSP gibi araçların hepsini elle kurmak (özellikle
Room'un derleme-zamanı kod üretimi — KSP — için gereken bileşenler) hem zaman
alır hem de sık sürüm uyumsuzluğu çıkarır. Yukarıdaki GitHub Actions yöntemi bu
sorunun tamamını ortadan kaldırır çünkü derleme senin cihazında değil, hazır
kurulmuş bir sunucuda yapılır.
