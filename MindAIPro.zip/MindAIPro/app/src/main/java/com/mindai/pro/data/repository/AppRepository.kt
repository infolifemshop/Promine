package com.mindai.pro.data.repository

import com.mindai.pro.data.local.AppDatabase
import com.mindai.pro.data.local.entities.BankAccountEntity
import com.mindai.pro.data.local.entities.BankTransactionEntity
import com.mindai.pro.data.local.entities.CashMovementEntity
import com.mindai.pro.data.local.entities.CheckEntity
import com.mindai.pro.data.local.entities.ContactEntity
import com.mindai.pro.data.local.entities.FinancialRecordEntity
import com.mindai.pro.data.local.entities.InvoiceEntity
import com.mindai.pro.data.local.entities.MindMapEdgeEntity
import com.mindai.pro.data.local.entities.MindMapNodeEntity
import com.mindai.pro.data.local.entities.PromissoryNoteEntity
import com.mindai.pro.data.local.entities.StockItemEntity
import com.mindai.pro.data.local.entities.TaskEntity
import com.mindai.pro.domain.ai.AIAnalysisService
import com.mindai.pro.domain.ai.AnalysisResult
import com.mindai.pro.domain.ai.toNodeType
import com.mindai.pro.domain.model.ContactType
import com.mindai.pro.domain.model.MovementDirection
import com.mindai.pro.domain.model.RecordStatus
import com.mindai.pro.domain.model.TaskStatus
import kotlinx.coroutines.flow.Flow

/**
 * Tek giriş noktası: UI/ViewModel katmanı doğrudan Room DAO'larıyla değil bu
 * repository ile konuşur. AI analiz sonucunu "öneri" olarak kaydeder — hiçbir
 * finansal kayıt kullanıcı onayı olmadan kesinleşmez (Bölüm 6/25/54).
 */
class AppRepository(private val db: AppDatabase) {

    // ---- Cari ----
    fun contacts(): Flow<List<ContactEntity>> = db.contactDao().getAll()
    suspend fun upsertContact(contact: ContactEntity): Long = db.contactDao().upsert(contact)
    suspend fun findSimilarContacts(namePart: String) = db.contactDao().findSimilar(namePart)

    // ---- Finansal kayıtlar ----
    fun financialRecords(): Flow<List<FinancialRecordEntity>> = db.financialRecordDao().getAll()
    fun pendingAiSuggestions(): Flow<List<FinancialRecordEntity>> = db.financialRecordDao().getBekleyenOneriler()
    fun toplamAlacak(): Flow<Double> = db.financialRecordDao().toplamAlacak()
    fun toplamBorc(): Flow<Double> = db.financialRecordDao().toplamBorc()
    fun bugunTahsilat(gunBaslangici: Long): Flow<Double> = db.financialRecordDao().bugunTahsilat(gunBaslangici)
    fun bugunOdeme(gunBaslangici: Long): Flow<Double> = db.financialRecordDao().bugunOdeme(gunBaslangici)

    suspend fun approveRecord(record: FinancialRecordEntity) {
        db.financialRecordDao().upsert(record.copy(aiOnerisiMi = false, durum = RecordStatus.EXPECTED))
    }

    suspend fun rejectRecord(record: FinancialRecordEntity) {
        db.financialRecordDao().delete(record)
    }

    // ---- Görevler ----
    fun tasks(): Flow<List<TaskEntity>> = db.taskDao().getAll()
    suspend fun approveTask(task: TaskEntity) {
        db.taskDao().upsert(task.copy(aiOnerisiMi = false, durum = TaskStatus.YAPILACAK))
    }
    suspend fun rejectTask(task: TaskEntity) = db.taskDao().delete(task)

    // ---- Zihin haritası ----
    fun mindMapNodes(): Flow<List<MindMapNodeEntity>> = db.mindMapDao().getAllNodes()
    fun mindMapEdges(): Flow<List<MindMapEdgeEntity>> = db.mindMapDao().getAllEdges()

    /**
     * AI analiz sonucunu veritabanına "öneri" (aiOnerisiMi = true, durum = UNCERTAIN)
     * olarak yazar. Kullanıcı onaylamadan hiçbir kalıcı cari/finansal kayıt oluşmaz.
     * Zihin haritası node/kenarları ise doğrudan görselleştirme amaçlı yazılır.
     */
    suspend fun persistAsSuggestions(result: AnalysisResult) {
        val localIdToNodeId = mutableMapOf<String, Long>()

        for (entity in result.entities) {
            val nodeId = db.mindMapDao().upsertNode(
                MindMapNodeEntity(tip = entity.toNodeType(), etiket = entity.name)
            )
            localIdToNodeId[entity.localId] = nodeId
        }

        for (rel in result.relationships) {
            val from = localIdToNodeId[rel.fromLocalId] ?: continue
            val to = localIdToNodeId[rel.toLocalId] ?: continue
            db.mindMapDao().upsertEdge(
                MindMapEdgeEntity(fromNodeId = from, toNodeId = to, etiket = rel.label)
            )
        }

        for (fr in result.financialRecords) {
            db.financialRecordDao().upsert(
                FinancialRecordEntity(
                    tur = fr.type,
                    contactId = null,
                    contactAdiGecici = fr.contactName,
                    aciklama = fr.description,
                    tutar = fr.amount,
                    durum = RecordStatus.UNCERTAIN, // onaylanana kadar kesinleşmez
                    vadeTarihi = null,
                    kaynakMetin = fr.sourceText,
                    aiOnerisiMi = true
                )
            )
        }

        for (t in result.tasks) {
            db.taskDao().upsert(
                TaskEntity(
                    baslik = t.title,
                    oncelik = t.priority,
                    durum = TaskStatus.BEKLIYOR,
                    kaynakMetin = t.sourceText,
                    aiOnerisiMi = true
                )
            )
        }
    }

    /** AI önerisinden gelen ismi mevcut bir cari ile eşleştirir veya yeni cari oluşturur. */
    suspend fun resolveOrCreateContact(name: String): Long {
        val existing = findSimilarContacts(name).firstOrNull()
        if (existing != null) return existing.id
        return upsertContact(ContactEntity(ad = name, tip = ContactType.DIGER, aiTarafindanMi = true))
    }

    // ---- Çekler ----
    fun checks(): Flow<List<CheckEntity>> = db.checkDao().getAll()
    suspend fun upsertCheck(check: CheckEntity): Long = db.checkDao().upsert(check)

    // ---- Senetler ----
    fun promissoryNotes(): Flow<List<PromissoryNoteEntity>> = db.promissoryNoteDao().getAll()
    suspend fun upsertPromissoryNote(note: PromissoryNoteEntity): Long = db.promissoryNoteDao().upsert(note)

    // ---- Bankalar ----
    fun bankAccounts(): Flow<List<BankAccountEntity>> = db.bankDao().getAllAccounts()
    fun bankTransactions(): Flow<List<BankTransactionEntity>> = db.bankDao().getAllTransactions()

    suspend fun addBankTransaction(accountId: Long, tutar: Double, yon: MovementDirection, aciklama: String?) {
        db.bankDao().upsertTransaction(
            BankTransactionEntity(bankAccountId = accountId, tutar = tutar, yon = yon, aciklama = aciklama)
        )
        val delta = if (yon == MovementDirection.GIRIS) tutar else -tutar
        db.bankDao().adjustBalance(accountId, delta)
    }

    suspend fun upsertBankAccount(account: BankAccountEntity): Long = db.bankDao().upsertAccount(account)

    // ---- Kasa ----
    fun cashMovements(): Flow<List<CashMovementEntity>> = db.cashDao().getAll()
    fun kasaBakiyesi(): Flow<Double> = db.cashDao().bakiye()
    suspend fun addCashMovement(movement: CashMovementEntity) = db.cashDao().upsert(movement)

    // ---- Faturalar ----
    fun invoices(): Flow<List<InvoiceEntity>> = db.invoiceDao().getAll()
    suspend fun upsertInvoice(invoice: InvoiceEntity): Long = db.invoiceDao().upsert(invoice)

    // ---- Stok ----
    fun stockItems(): Flow<List<StockItemEntity>> = db.stockDao().getAll()
    suspend fun upsertStockItem(item: StockItemEntity): Long = db.stockDao().upsert(item)
}
