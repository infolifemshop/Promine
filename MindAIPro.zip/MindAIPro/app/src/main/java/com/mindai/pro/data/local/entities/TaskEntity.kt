package com.mindai.pro.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mindai.pro.domain.model.TaskPriority
import com.mindai.pro.domain.model.TaskStatus

/** Görev — bkz. Bölüm 17. */
@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val baslik: String,
    val iliskiliContactId: Long? = null,
    val oncelik: TaskPriority = TaskPriority.ORTA,
    val durum: TaskStatus = TaskStatus.YAPILACAK,
    val vadeTarihi: Long? = null, // null => "Tarih belirtilmedi" grubu
    val kaynakMetin: String? = null,
    val aiOnerisiMi: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
