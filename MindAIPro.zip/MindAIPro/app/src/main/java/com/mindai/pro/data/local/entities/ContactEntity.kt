package com.mindai.pro.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mindai.pro.domain.model.ContactType

/**
 * Cari hesap kartı — bkz. Birleşik Spesifikasyon Bölüm 8.
 */
@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ad: String,
    val firma: String? = null,
    val telefon: String? = null,
    val eposta: String? = null,
    val adres: String? = null,
    val tip: ContactType = ContactType.DIGER,
    val not: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    /** AI tarafından mı önerildi, kullanıcı tarafından mı onaylandı — duplicate kontrolü için (Bölüm 6). */
    val aiTarafindanMi: Boolean = false
)
