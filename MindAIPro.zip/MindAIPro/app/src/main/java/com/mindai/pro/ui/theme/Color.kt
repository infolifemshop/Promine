package com.mindai.pro.ui.theme

import androidx.compose.ui.graphics.Color

// Bkz. Birleşik Spesifikasyon Bölüm 21 — UI Tasarım renk paleti.
val MindPrimaryDark = Color(0xFF0B1930)
val MindBlue = Color(0xFF2563EB)
val MindAiAccent = Color(0xFF4F7CFF)
val MindGreen = Color(0xFF22A06B)
val MindOrange = Color(0xFFF59E0B)
val MindRed = Color(0xFFEF4444)
val MindBackground = Color(0xFFF7F9FC)
val MindCard = Color(0xFFFFFFFF)
