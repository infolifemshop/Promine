package com.mindai.pro.ui.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mindai.pro.R
import com.mindai.pro.data.local.entities.FinancialRecordEntity
import com.mindai.pro.ui.components.formatTl

@Composable
fun AiSonucScreen(
    viewModel: AiSharedViewModel,
    onHaritayaGit: () -> Unit,
    onBitti: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val oneriler by viewModel.bekleyenFinansalOneriler.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.analiz_tamamlandi), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

        (state as? AiUiState.Sonuc)?.let { s ->
            Spacer(Modifier.height(8.dp))
            Text(s.result.summary, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onHaritayaGit) { Text(stringResource(R.string.btn_haritaya_bak)) }
            Button(onClick = onBitti) { Text(stringResource(R.string.btn_hepsini_onayla)) }
        }

        Spacer(Modifier.height(16.dp))

        if (oneriler.isEmpty()) {
            Text(stringResource(R.string.bos_islem_yok), style = MaterialTheme.typography.bodyMedium)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(oneriler, key = { it.id }) { record ->
                    OneriKarti(
                        record = record,
                        onOnayla = { viewModel.onaylaKayit(record) },
                        onReddet = { viewModel.reddetKayit(record) }
                    )
                }
            }
        }
    }
}

@Composable
private fun OneriKarti(
    record: FinancialRecordEntity,
    onOnayla: () -> Unit,
    onReddet: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(
                stringResource(R.string.yapay_zeka_onerisi),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(record.contactAdiGecici ?: record.aciklama, style = MaterialTheme.typography.titleMedium)
            Text(record.aciklama, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            Text(formatTl(record.tutar), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onOnayla) { Text(stringResource(R.string.btn_onayla)) }
                OutlinedButton(onClick = onReddet) { Text(stringResource(R.string.btn_reddet)) }
            }
        }
    }
}
