package com.mindai.pro.domain.model

import androidx.annotation.StringRes
import com.mindai.pro.R

/** Çek durumu — Bölüm 13. */
enum class CheckStatus(@StringRes val label: Int) {
    BEKLENIYOR(R.string.cek_bekleniyor),
    ALINDI(R.string.cek_alindi),
    PORTFOYDE(R.string.cek_portfoyde),
    BANKAYA_VERILDI(R.string.cek_bankaya_verildi),
    TAHSIL_EDILDI(R.string.cek_tahsil_edildi),
    CIRO_EDILDI(R.string.cek_ciro_edildi),
    IADE_EDILDI(R.string.cek_iade_edildi),
    KARSILIKSIZ(R.string.cek_karsiliksiz)
}

/** Senet durumu — Bölüm 14. */
enum class NoteStatus(@StringRes val label: Int) {
    BEKLENIYOR(R.string.senet_bekleniyor),
    ALINDI(R.string.senet_alindi),
    VERILDI(R.string.senet_verildi),
    TAHSIL_EDILDI(R.string.tahsil_edildi),
    ODENDI(R.string.senet_odendi),
    GECIKTI(R.string.odeme_gecikti),
    IPTAL(R.string.durum_iptal_edildi)
}

/** Fatura durumu — Bölüm 19. */
enum class InvoiceStatus(@StringRes val label: Int) {
    TASLAK(R.string.fatura_taslak),
    KESILDI(R.string.fatura_kesildi),
    GONDERILDI(R.string.fatura_gonderildi),
    ODENDI(R.string.fatura_odendi),
    KISMI_ODENDI(R.string.fatura_kismi_odendi),
    GECIKMIS(R.string.fatura_gecikmis),
    IPTAL(R.string.durum_iptal_edildi)
}

/** Banka/Kasa hareket yönü. */
enum class MovementDirection(@StringRes val label: Int) {
    GIRIS(R.string.hareket_giris),
    CIKIS(R.string.hareket_cikis)
}
