package com.mindai.pro.ui.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.mindai.pro.R

private val analizAdimlari = listOf(
    R.string.ai_adim_1, R.string.ai_adim_2, R.string.ai_adim_3, R.string.ai_adim_4,
    R.string.ai_adim_5, R.string.ai_adim_6, R.string.ai_adim_7, R.string.ai_adim_8, R.string.ai_adim_9
)

@Composable
fun AiGirisScreen(
    viewModel: AiSharedViewModel,
    onAnalizTamamlandi: () -> Unit
) {
    var metin by remember { mutableStateOf("") }
    val state by viewModel.state.collectAsState()

    LaunchedEffect(state) {
        if (state is AiUiState.Sonuc) onAnalizTamamlandi()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(stringResource(R.string.ai_giris_sorusu), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.ai_giris_aciklama), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = metin,
            onValueChange = { metin = it },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f, fill = false)
                .heightIn(min = 160.dp),
            placeholder = { Text(stringResource(R.string.ai_giris_placeholder)) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
            enabled = state !is AiUiState.Analiz
        )

        Spacer(Modifier.height(16.dp))

        when (val s = state) {
            is AiUiState.Analiz -> {
                Column {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text(stringResource(analizAdimlari.getOrElse(s.adimIndex) { R.string.ai_adim_son }))
                }
            }
            else -> {
                Button(
                    onClick = { viewModel.analyze(metin) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = metin.isNotBlank()
                ) {
                    Text(stringResource(R.string.btn_ai_ile_analiz_et))
                }
            }
        }
    }
}
