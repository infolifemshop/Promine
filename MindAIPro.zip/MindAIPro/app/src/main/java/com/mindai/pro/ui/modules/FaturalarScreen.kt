package com.mindai.pro.ui.modules

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindai.pro.R
import com.mindai.pro.data.local.entities.InvoiceEntity
import com.mindai.pro.data.repository.AppRepository
import com.mindai.pro.ui.components.formatTl
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FaturaViewModel(private val repository: AppRepository) : ViewModel() {
    val invoices: StateFlow<List<InvoiceEntity>> =
        repository.invoices().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun ekle(faturaNo: String, contactAdi: String, tutar: Double) = viewModelScope.launch {
        repository.upsertInvoice(InvoiceEntity(faturaNo = faturaNo, contactAdi = contactAdi, tutar = tutar))
    }
}

@Composable
fun FaturalarScreen(viewModel: FaturaViewModel) {
    val invoices by viewModel.invoices.collectAsState()
    var dialogAcik by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { dialogAcik = true }) { Icon(Icons.Filled.Add, contentDescription = null) }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(stringResource(R.string.menu_faturalar), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            if (invoices.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.bos_kayit_yok))
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(invoices, key = { it.id }) { invoice ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(invoice.faturaNo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text(invoice.contactAdi, style = MaterialTheme.typography.bodyMedium)
                                Spacer(Modifier.height(4.dp))
                                Text(formatTl(invoice.tutar), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(stringResource(invoice.durum.label), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }

    if (dialogAcik) {
        var faturaNo by remember { mutableStateOf("") }
        var contactAdi by remember { mutableStateOf("") }
        var tutar by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { dialogAcik = false },
            title = { Text(stringResource(R.string.btn_yeni_kayit_ekle)) },
            text = {
                Column {
                    OutlinedTextField(faturaNo, { faturaNo = it }, label = { Text(stringResource(R.string.alan_fatura_no)) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(contactAdi, { contactAdi = it }, label = { Text(stringResource(R.string.alan_kisi_adi)) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(tutar, { tutar = it }, label = { Text(stringResource(R.string.alan_tutar)) }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = tutar.replace(",", ".").toDoubleOrNull()
                    if (faturaNo.isNotBlank() && contactAdi.isNotBlank() && t != null) {
                        viewModel.ekle(faturaNo, contactAdi, t)
                        dialogAcik = false
                    }
                }) { Text(stringResource(R.string.btn_olustur)) }
            },
            dismissButton = {
                TextButton(onClick = { dialogAcik = false }) { Text(stringResource(R.string.btn_iptal)) }
            }
        )
    }
}
