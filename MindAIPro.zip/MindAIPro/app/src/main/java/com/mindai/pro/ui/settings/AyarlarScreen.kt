package com.mindai.pro.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mindai.pro.R

private val settingsSections = listOf(
    R.string.ayarlar_profil,
    R.string.ayarlar_isletme_bilgileri,
    R.string.ayarlar_para_birimi,
    R.string.ayarlar_kdv,
    R.string.ayarlar_bildirimler,
    R.string.ayarlar_yapay_zeka,
    R.string.ayarlar_veri_yedekleme,
    R.string.ayarlar_guvenlik,
    R.string.ayarlar_gorunum,
    R.string.ayarlar_hakkinda
)

@Composable
fun AyarlarScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.menu_ayarlar), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(settingsSections) { labelRes ->
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stringResource(labelRes), style = MaterialTheme.typography.bodyLarge)
                        Icon(Icons.Filled.ChevronRight, contentDescription = null)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        // Varsayılan yerel ayar — Bölüm 27: Dil Türkçe, Ülke Türkiye, Para birimi TL, Tarih gg.aa.yyyy, Saat 24h.
        Text(
            "${stringResource(R.string.app_name)} • Türkçe • Türkiye • TL",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
