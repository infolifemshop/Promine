package com.mindai.pro.domain.ai

/**
 * "iki yüz elli bin" -> 250000.0 gibi Türkçe yazılı sayıları çözer.
 * Bölüm 25/40'ta istenen "Türkçe sayı anlama" kuralının basit, genişletilebilir uygulaması.
 */
object TurkishNumberParser {

    private val units = mapOf(
        "bir" to 1, "iki" to 2, "üç" to 3, "dört" to 4, "beş" to 5,
        "altı" to 6, "yedi" to 7, "sekiz" to 8, "dokuz" to 9
    )
    private val tens = mapOf(
        "on" to 10, "yirmi" to 20, "otuz" to 30, "kırk" to 40, "elli" to 50,
        "altmış" to 60, "yetmiş" to 70, "seksen" to 80, "doksan" to 90
    )
    private val scales = mapOf(
        "yüz" to 100L, "bin" to 1_000L, "milyon" to 1_000_000L, "milyar" to 1_000_000_000L
    )

    /** Metindeki yazılı Türkçe sayı ifadelerini yakalar ve TL tutarına çevirir. */
    fun findWrittenAmounts(text: String): List<Pair<String, Double>> {
        val lower = text.lowercase()
        val words = lower.split(Regex("[^a-zçğıöşü]+")).filter { it.isNotBlank() }
        val results = mutableListOf<Pair<String, Double>>()
        var i = 0
        while (i < words.size) {
            if (units.containsKey(words[i]) || tens.containsKey(words[i]) || scales.containsKey(words[i])) {
                var j = i
                var total = 0L
                var current = 0L
                val consumed = mutableListOf<String>()
                while (j < words.size && (units.containsKey(words[j]) || tens.containsKey(words[j]) || scales.containsKey(words[j]))) {
                    val w = words[j]
                    when {
                        units.containsKey(w) -> current += units.getValue(w)
                        tens.containsKey(w) -> current += tens.getValue(w)
                        w == "yüz" -> current = if (current == 0L) 100 else current * 100
                        w == "bin" || w == "milyon" || w == "milyar" -> {
                            current = if (current == 0L) 1 else current
                            total += current * scales.getValue(w)
                            current = 0
                        }
                    }
                    consumed += w
                    j++
                }
                val value = (total + current).toDouble()
                if (value > 0) results += consumed.joinToString(" ") to value
                i = j
            } else {
                i++
            }
        }
        return results
    }
}
