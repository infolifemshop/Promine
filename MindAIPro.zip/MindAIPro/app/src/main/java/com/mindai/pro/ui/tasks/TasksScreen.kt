package com.mindai.pro.ui.tasks

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mindai.pro.R
import com.mindai.pro.data.local.entities.TaskEntity
import com.mindai.pro.domain.model.TaskPriority
import com.mindai.pro.ui.theme.MindBlue
import com.mindai.pro.ui.theme.MindOrange
import com.mindai.pro.ui.theme.MindRed

@Composable
fun TasksScreen(viewModel: TasksViewModel) {
    val tasks by viewModel.tasks.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.nav_gorevler), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))

        if (tasks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.bos_gorev_yok))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tasks, key = { it.id }) { task -> GorevKarti(task) }
            }
        }
    }
}

@Composable
private fun GorevKarti(task: TaskEntity) {
    val renk = when (task.oncelik) {
        TaskPriority.KRITIK -> MindRed
        TaskPriority.YUKSEK -> MindOrange
        else -> MindBlue
    }
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(10.dp)
                    .background(renk, shape = androidx.compose.foundation.shape.CircleShape)
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(task.baslik, style = MaterialTheme.typography.titleMedium)
                Text(stringResource(task.oncelik.label), style = MaterialTheme.typography.labelSmall, color = renk)
            }
        }
    }
}
