package com.mindai.pro.domain.ai

import com.mindai.pro.domain.model.FinancialRecordType
import com.mindai.pro.domain.model.NodeType
import com.mindai.pro.domain.model.RecordStatus
import com.mindai.pro.domain.model.TaskPriority
import kotlinx.serialization.Serializable

/**
 * AI Service çıktısı — STRICT JSON şeması (Bölüm 22/73).
 * UI bu veriyi doğrudan doğal dilden parse etmeye çalışmaz; her zaman bu modele güvenir.
 */
@Serializable
data class AnalysisResult(
    val title: String,
    val summary: String,
    val entities: List<ExtractedEntity>,
    val relationships: List<ExtractedRelationship>,
    val financialRecords: List<ExtractedFinancialRecord>,
    val tasks: List<ExtractedTask>
)

@Serializable
data class ExtractedEntity(
    val localId: String,
    val type: String, // "KISI" | "PARA" | "IS" | "YER" | "TARIH"
    val name: String,
    val confidence: Double,
    val sourceText: String
)

@Serializable
data class ExtractedRelationship(
    val fromLocalId: String,
    val toLocalId: String,
    val label: String, // Türkçe ilişki etiketi
    val confidence: Double
)

@Serializable
data class ExtractedFinancialRecord(
    val type: FinancialRecordType,
    val contactName: String?,
    val description: String,
    val amount: Double,
    val status: RecordStatus,
    val dueDateLabel: String?, // "yarın" gibi ham ifade; kesinleştirme UI'da yapılır
    val sourceText: String
)

@Serializable
data class ExtractedTask(
    val title: String,
    val relatedContactName: String?,
    val priority: TaskPriority,
    val sourceText: String
)

fun ExtractedEntity.toNodeType(): NodeType = when (type) {
    "KISI" -> NodeType.KISI
    "PARA" -> NodeType.PARA
    "IS" -> NodeType.IS
    "TARIH" -> NodeType.TARIH
    else -> NodeType.IS
}
