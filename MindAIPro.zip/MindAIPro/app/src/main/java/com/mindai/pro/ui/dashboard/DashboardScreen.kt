package com.mindai.pro.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mindai.pro.R
import com.mindai.pro.ui.components.formatTl
import com.mindai.pro.ui.theme.MindAiAccent

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onAiGirisTiklandi: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(stringResourceCompat(R.string.app_name), style = MaterialTheme.typography.headlineMedium)
        Text(
            stringResourceCompat(R.string.ana_sayfa_alt_baslik),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(16.dp))

        Card(
            onClick = onAiGirisTiklandi,
            colors = CardDefaults.cardColors(containerColor = MindAiAccent.copy(alpha = 0.1f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MindAiAccent)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        stringResourceCompat(R.string.ai_giris_sorusu),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(stringResourceCompat(R.string.ai_giris_aciklama), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onAiGirisTiklandi) {
                    Text(stringResourceCompat(R.string.btn_ai_ile_analiz_et))
                }
                if (state.bekleyenOneriSayisi > 0) {
                    Spacer(Modifier.height(8.dp))
                    AssistChip(
                        onClick = onAiGirisTiklandi,
                        label = { Text(pluralOneriMesaji(state.bekleyenOneriSayisi)) }
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(dashboardCards(state)) { card ->
                DashboardCard(card.first, card.second)
            }
        }
    }
}

private fun dashboardCards(state: DashboardUiState): List<Pair<Int, String>> = listOf(
    R.string.kart_toplam_alacak to formatTl(state.toplamAlacak),
    R.string.kart_toplam_borc to formatTl(state.toplamBorc),
    R.string.kart_bugun_tahsilat to formatTl(state.bugunTahsilat),
    R.string.kart_bugun_odeme to formatTl(state.bugunOdeme)
)

@Composable
private fun DashboardCard(titleRes: Int, value: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(stringResourceCompat(titleRes), style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

// androidx.compose.ui.res.stringResource kısayolu (Composable içinde import karmaşasını azaltmak için).
@Composable
private fun stringResourceCompat(id: Int): String = androidx.compose.ui.res.stringResource(id)

@Composable
private fun pluralOneriMesaji(sayi: Int): String =
    androidx.compose.ui.res.stringResource(R.string.bekleyen_ai_onerisi_format, sayi)
