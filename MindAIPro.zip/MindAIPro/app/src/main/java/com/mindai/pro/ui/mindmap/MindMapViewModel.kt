package com.mindai.pro.ui.mindmap

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindai.pro.data.local.entities.MindMapEdgeEntity
import com.mindai.pro.data.local.entities.MindMapNodeEntity
import com.mindai.pro.data.repository.AppRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class MindMapUiState(
    val nodes: List<MindMapNodeEntity> = emptyList(),
    val edges: List<MindMapEdgeEntity> = emptyList()
)

class MindMapViewModel(repository: AppRepository) : ViewModel() {
    val uiState: StateFlow<MindMapUiState> = combine(
        repository.mindMapNodes(), repository.mindMapEdges()
    ) { nodes, edges -> MindMapUiState(nodes, edges) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MindMapUiState())
}
