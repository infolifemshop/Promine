package com.mindai.pro.ui.navigation

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mindai.pro.MindAIApplication
import com.mindai.pro.ui.MindAIViewModelFactory
import com.mindai.pro.ui.ai.AiGirisScreen
import com.mindai.pro.ui.ai.AiSharedViewModel
import com.mindai.pro.ui.ai.AiSonucScreen
import com.mindai.pro.ui.contacts.ContactsScreen
import com.mindai.pro.ui.contacts.ContactsViewModel
import com.mindai.pro.ui.dashboard.DashboardScreen
import com.mindai.pro.ui.dashboard.DashboardViewModel
import com.mindai.pro.ui.mindmap.MindMapScreen
import com.mindai.pro.ui.mindmap.MindMapViewModel
import com.mindai.pro.ui.modules.BankaViewModel
import com.mindai.pro.ui.modules.BankalarScreen
import com.mindai.pro.ui.modules.CekViewModel
import com.mindai.pro.ui.modules.CeklerScreen
import com.mindai.pro.ui.modules.FaturaViewModel
import com.mindai.pro.ui.modules.FaturalarScreen
import com.mindai.pro.ui.modules.KasaScreen
import com.mindai.pro.ui.modules.KasaViewModel
import com.mindai.pro.ui.modules.SenetViewModel
import com.mindai.pro.ui.modules.SenetlerScreen
import com.mindai.pro.ui.modules.StokViewModel
import com.mindai.pro.ui.modules.StoklarScreen
import com.mindai.pro.ui.more.DahaFazlaModule
import com.mindai.pro.ui.more.DahaFazlaScreen
import com.mindai.pro.R
import com.mindai.pro.ui.settings.AyarlarScreen
import com.mindai.pro.ui.tasks.TasksScreen
import com.mindai.pro.ui.tasks.TasksViewModel

private val dahaFazlaModules = listOf(
    DahaFazlaModule(R.string.menu_gelirler, Screen.Cari.route), // Bölüm 9: FinancialRecordEntity üzerinden Cari Hesaplar'da bakiye olarak görünür
    DahaFazlaModule(R.string.menu_giderler, Screen.Cari.route),
    DahaFazlaModule(R.string.menu_tahsilatlar, Screen.Cari.route),
    DahaFazlaModule(R.string.menu_odemeler, Screen.Cari.route),
    DahaFazlaModule(R.string.menu_cekler, Screen.Cekler.route),
    DahaFazlaModule(R.string.menu_senetler, Screen.Senetler.route),
    DahaFazlaModule(R.string.menu_kasa, Screen.Kasa.route),
    DahaFazlaModule(R.string.menu_bankalar, Screen.Bankalar.route),
    DahaFazlaModule(R.string.menu_faturalar, Screen.Faturalar.route),
    DahaFazlaModule(R.string.menu_stoklar, Screen.Stoklar.route),
    DahaFazlaModule(R.string.menu_raporlar, Screen.Cari.route),
    DahaFazlaModule(R.string.menu_ayarlar, Screen.Ayarlar.route)
)

/**
 * Uygulamanın tek NavHost'u. Alt navigasyon (Bölüm 3) her zaman görünür;
 * AI Giriş/Sonuç ve Ayarlar ekranları üstüne açılan ayrı rotalardır.
 */
@Composable
fun MindAINavGraph(app: MindAIApplication) {
    val navController = rememberNavController()
    val factory = MindAIViewModelFactory(app)

    // Activity-scoped AI ViewModel: AI Giriş ve AI Sonuç ekranları arasında paylaşılır.
    val aiSharedViewModel: AiSharedViewModel = viewModel(factory = factory)

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val bottomBarRoutes = bottomNavItems.map { it.screen.route }.toSet()
    val showBottomBar = currentDestination?.route in bottomBarRoutes

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomNavItems.forEach { item ->
                        val selected = currentDestination?.hierarchy?.any { it.route == item.screen.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(item.screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(stringResource(item.labelRes)) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.AnaSayfa.route,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {
            composable(Screen.AnaSayfa.route) {
                val vm: DashboardViewModel = viewModel(factory = factory)
                DashboardScreen(
                    viewModel = vm,
                    onAiGirisTiklandi = {
                        aiSharedViewModel.reset()
                        navController.navigate(Screen.AiGiris.route)
                    }
                )
            }
            composable(Screen.ZihinHaritasi.route) {
                val vm: MindMapViewModel = viewModel(factory = factory)
                MindMapScreen(vm)
            }
            composable(Screen.Gorevler.route) {
                val vm: TasksViewModel = viewModel(factory = factory)
                TasksScreen(vm)
            }
            composable(Screen.Cari.route) {
                val vm: ContactsViewModel = viewModel(factory = factory)
                ContactsScreen(vm)
            }
            composable(Screen.DahaFazla.route) {
                DahaFazlaScreen(
                    modules = dahaFazlaModules,
                    onModuleTiklandi = { route -> navController.navigate(route) }
                )
            }
            composable(Screen.Ayarlar.route) {
                AyarlarScreen()
            }
            composable(Screen.Cekler.route) {
                val vm: CekViewModel = viewModel(factory = factory)
                CeklerScreen(vm)
            }
            composable(Screen.Senetler.route) {
                val vm: SenetViewModel = viewModel(factory = factory)
                SenetlerScreen(vm)
            }
            composable(Screen.Bankalar.route) {
                val vm: BankaViewModel = viewModel(factory = factory)
                BankalarScreen(vm)
            }
            composable(Screen.Kasa.route) {
                val vm: KasaViewModel = viewModel(factory = factory)
                KasaScreen(vm)
            }
            composable(Screen.Faturalar.route) {
                val vm: FaturaViewModel = viewModel(factory = factory)
                FaturalarScreen(vm)
            }
            composable(Screen.Stoklar.route) {
                val vm: StokViewModel = viewModel(factory = factory)
                StoklarScreen(vm)
            }
            composable(Screen.AiGiris.route) {
                AiGirisScreen(
                    viewModel = aiSharedViewModel,
                    onAnalizTamamlandi = { navController.navigate(Screen.AiSonuc.route) }
                )
            }
            composable(Screen.AiSonuc.route) {
                AiSonucScreen(
                    viewModel = aiSharedViewModel,
                    onHaritayaGit = {
                        navController.navigate(Screen.ZihinHaritasi.route) {
                            popUpTo(Screen.AnaSayfa.route)
                        }
                    },
                    onBitti = {
                        navController.navigate(Screen.AnaSayfa.route) {
                            popUpTo(Screen.AnaSayfa.route) { inclusive = true }
                        }
                    }
                )
            }
        }
    }
}
