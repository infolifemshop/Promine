package com.mindai.pro.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindai.pro.data.repository.AppRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.util.Calendar

data class DashboardUiState(
    val toplamAlacak: Double = 0.0,
    val toplamBorc: Double = 0.0,
    val bugunTahsilat: Double = 0.0,
    val bugunOdeme: Double = 0.0,
    val bekleyenOneriSayisi: Int = 0
)

class DashboardViewModel(repository: AppRepository) : ViewModel() {

    private val gunBaslangici: Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
    }.timeInMillis

    val uiState: StateFlow<DashboardUiState> = combine(
        repository.toplamAlacak(),
        repository.toplamBorc(),
        repository.bugunTahsilat(gunBaslangici),
        repository.bugunOdeme(gunBaslangici),
        repository.pendingAiSuggestions()
    ) { alacak, borc, tahsilat, odeme, oneriler ->
        DashboardUiState(alacak, borc, tahsilat, odeme, oneriler.size)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())
}
