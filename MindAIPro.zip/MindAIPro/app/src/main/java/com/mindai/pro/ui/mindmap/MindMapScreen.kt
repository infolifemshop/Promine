package com.mindai.pro.ui.mindmap

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mindai.pro.R
import com.mindai.pro.domain.model.NodeType
import com.mindai.pro.ui.theme.MindAiAccent
import com.mindai.pro.ui.theme.MindBlue
import com.mindai.pro.ui.theme.MindGreen
import com.mindai.pro.ui.theme.MindOrange
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MindMapScreen(viewModel: MindMapViewModel) {
    val state by viewModel.uiState.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.nav_zihin_haritasi), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.harita_baslik_varsayilan), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))

        if (state.nodes.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text(stringResource(R.string.bos_kayit_yok))
            }
        } else {
            val positions = remember(state.nodes) { circularLayout(state.nodes.size) }
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val idToOffset = state.nodes.mapIndexed { idx, n -> n.id to positions[idx].scaledTo(w, h) }.toMap()

                // Kenarlar
                state.edges.forEach { edge ->
                    val from = idToOffset[edge.fromNodeId]
                    val to = idToOffset[edge.toNodeId]
                    if (from != null && to != null) {
                        drawLine(color = MindBlue.copy(alpha = 0.5f), start = from, end = to, strokeWidth = 3f)
                        drawEdgeLabel(edge.etiket, from, to)
                    }
                }

                // Node'lar
                state.nodes.forEachIndexed { idx, node ->
                    val offset = positions[idx].scaledTo(w, h)
                    val color = when (node.tip) {
                        NodeType.KISI -> MindAiAccent
                        NodeType.PARA -> MindGreen
                        NodeType.GOREV -> MindOrange
                        else -> MindBlue
                    }
                    drawCircle(color = color, radius = 26f, center = offset)
                    drawNodeLabel(node.etiket, offset)
                }
            }
        }
    }
}

private data class RelativePoint(val fx: Float, val fy: Float) {
    fun scaledTo(w: Float, h: Float) = Offset(fx * w, fy * h)
}

private fun circularLayout(count: Int): List<RelativePoint> {
    if (count == 0) return emptyList()
    return (0 until count).map { i ->
        val angle = (2 * Math.PI * i / count).toFloat()
        RelativePoint(
            fx = 0.5f + 0.35f * cos(angle),
            fy = 0.5f + 0.35f * sin(angle)
        )
    }
}

private fun DrawScope.drawNodeLabel(text: String, offset: Offset) {
    drawContext.canvas.nativeCanvas.apply {
        val paint = android.graphics.Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 28f
            textAlign = android.graphics.Paint.Align.CENTER
        }
        drawText(text, offset.x, offset.y + 50f, paint)
    }
}

private fun DrawScope.drawEdgeLabel(text: String, from: Offset, to: Offset) {
    val mid = Offset((from.x + to.x) / 2, (from.y + to.y) / 2)
    drawContext.canvas.nativeCanvas.apply {
        val paint = android.graphics.Paint().apply {
            color = android.graphics.Color.DKGRAY
            textSize = 22f
            textAlign = android.graphics.Paint.Align.CENTER
        }
        drawText(text, mid.x, mid.y, paint)
    }
}
