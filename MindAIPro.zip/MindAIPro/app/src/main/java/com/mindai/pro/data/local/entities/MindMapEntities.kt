package com.mindai.pro.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mindai.pro.domain.model.NodeType

/**
 * Zihin haritası node'u — Bölüm 15/31. `entityId` aynı kişi/tutar birden fazla
 * anlatımda geçtiğinde eşleşme kurmak için kullanılır (duplicate kontrolü, Bölüm 6/52).
 */
@Entity(tableName = "mind_map_nodes")
data class MindMapNodeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tip: NodeType,
    val etiket: String,
    val iliskiliContactId: Long? = null,
    val iliskiliRecordId: Long? = null,
    val iliskiliTaskId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/** Node'lar arası ilişki (kenar) — Bölüm 15/51. */
@Entity(tableName = "mind_map_edges")
data class MindMapEdgeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromNodeId: Long,
    val toNodeId: Long,
    val etiket: String, // RelationshipLabel.turkce değeri
    val kaynakMetin: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
