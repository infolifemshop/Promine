package com.mindai.pro.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.ui.graphics.vector.ImageVector
import com.mindai.pro.R

data class BottomNavItem(
    val screen: Screen,
    val labelRes: Int,
    val icon: ImageVector
)

val bottomNavItems = listOf(
    BottomNavItem(Screen.AnaSayfa, R.string.nav_ana_sayfa, Icons.Filled.Home),
    BottomNavItem(Screen.ZihinHaritasi, R.string.nav_zihin_haritasi, Icons.Filled.AccountTree),
    BottomNavItem(Screen.Gorevler, R.string.nav_gorevler, Icons.Filled.CheckCircle),
    BottomNavItem(Screen.Cari, R.string.nav_cari, Icons.Filled.AccountBalance),
    BottomNavItem(Screen.DahaFazla, R.string.nav_daha_fazla, Icons.Filled.MoreHoriz)
)
