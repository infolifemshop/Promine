package com.mindai.pro.ui.modules

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindai.pro.R
import com.mindai.pro.data.local.entities.BankAccountEntity
import com.mindai.pro.data.repository.AppRepository
import com.mindai.pro.ui.components.formatTl
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BankaViewModel(private val repository: AppRepository) : ViewModel() {
    val accounts: StateFlow<List<BankAccountEntity>> =
        repository.bankAccounts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun ekle(bankaAdi: String) = viewModelScope.launch {
        repository.upsertBankAccount(BankAccountEntity(bankaAdi = bankaAdi))
    }
}

@Composable
fun BankalarScreen(viewModel: BankaViewModel) {
    val accounts by viewModel.accounts.collectAsState()
    var dialogAcik by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { dialogAcik = true }) { Icon(Icons.Filled.Add, contentDescription = null) }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(stringResource(R.string.menu_bankalar), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            if (accounts.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.bos_kayit_yok))
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(accounts, key = { it.id }) { account ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(account.bankaAdi, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(4.dp))
                                Text(stringResource(R.string.bakiye_etiketi), style = MaterialTheme.typography.labelSmall)
                                Text(formatTl(account.bakiye), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (dialogAcik) {
        var bankaAdi by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { dialogAcik = false },
            title = { Text(stringResource(R.string.btn_yeni_kayit_ekle)) },
            text = {
                OutlinedTextField(bankaAdi, { bankaAdi = it }, label = { Text(stringResource(R.string.alan_banka_adi)) }, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                TextButton(onClick = {
                    if (bankaAdi.isNotBlank()) {
                        viewModel.ekle(bankaAdi)
                        dialogAcik = false
                    }
                }) { Text(stringResource(R.string.btn_olustur)) }
            },
            dismissButton = {
                TextButton(onClick = { dialogAcik = false }) { Text(stringResource(R.string.btn_iptal)) }
            }
        )
    }
}
