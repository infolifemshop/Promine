package com.mindai.pro.domain.model

import androidx.annotation.StringRes
import com.mindai.pro.R

/**
 * Finansal kayıt durumu.
 * Bkz. spesifikasyon Bölüm 7 — AI bu durumu anlatımdaki kesinlik derecesine göre atar.
 */
enum class RecordStatus(@StringRes val label: Int) {
    EXPECTED(R.string.durum_bekleniyor),
    CONFIRMED(R.string.durum_kesinlesti),
    COMPLETED(R.string.durum_tamamlandi),
    UNCERTAIN(R.string.durum_belirsiz),
    CANCELLED(R.string.durum_iptal_edildi)
}

/** Cari hesap sınıflandırması. */
enum class ContactType(@StringRes val label: Int) {
    MUSTERI(R.string.cari_musteriler),
    TEDARIKCI(R.string.cari_tedarikciler),
    DIGER(R.string.cari_diger_kisiler)
}

/**
 * Ön muhasebe kaydının türü. Gelir/Gider/Tahsilat/Ödeme aynı tabloda tutulur,
 * yön (income/expense/collection/payment) bu alanla ayrılır — bkz. Bölüm 9.
 */
enum class FinancialRecordType(@StringRes val label: Int) {
    GELIR(R.string.menu_gelirler),
    GIDER(R.string.menu_giderler),
    TAHSILAT(R.string.menu_tahsilatlar),
    ODEME(R.string.menu_odemeler)
}

enum class TaskPriority(@StringRes val label: Int) {
    KRITIK(R.string.oncelik_kritik),
    YUKSEK(R.string.oncelik_yuksek),
    ORTA(R.string.oncelik_orta),
    DUSUK(R.string.oncelik_dusuk)
}

enum class TaskStatus(@StringRes val label: Int) {
    YAPILACAK(R.string.gorev_yapilacak),
    DEVAM_EDIYOR(R.string.gorev_devam_ediyor),
    BEKLIYOR(R.string.gorev_bekliyor),
    TAMAMLANDI(R.string.gorev_tamamlandi),
    IPTAL(R.string.durum_iptal_edildi)
}

/** Zihin haritası node türleri — bkz. Bölüm 15. */
enum class NodeType(@StringRes val label: Int) {
    KISI(R.string.harita_node_kisi),
    IS(R.string.harita_node_is),
    PARA(R.string.harita_node_para),
    GOREV(R.string.harita_node_gorev),
    TARIH(R.string.harita_node_tarih)
}

/** Harita bağlantı (ilişki) etiketleri — sabit Türkçe metinler, kod içinde çevrilmez. */
enum class RelationshipLabel(val turkce: String) {
    ODEME_YAPACAK("Ödeme yapacak"),
    ODEME_ALACAK("Ödeme alacak"),
    BORCLU("Borçlu"),
    ALACAKLI("Alacaklı"),
    BAGLI("Bağlı"),
    GEREKTIRIYOR("Gerektiriyor"),
    BEKLENIYOR("Bekleniyor"),
    TAKIP_EDILMELI("Takip edilmeli"),
    ILISKILI("İlişkili")
}
