package com.mindai.pro.data.local.dao

import androidx.room.*
import com.mindai.pro.data.local.entities.ContactEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts ORDER BY ad ASC")
    fun getAll(): Flow<List<ContactEntity>>

    @Query("SELECT * FROM contacts WHERE id = :id")
    suspend fun getById(id: Long): ContactEntity?

    @Query("SELECT * FROM contacts WHERE ad LIKE '%' || :query || '%' OR firma LIKE '%' || :query || '%'")
    fun search(query: String): Flow<List<ContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(contact: ContactEntity): Long

    @Delete
    suspend fun delete(contact: ContactEntity)

    /** Ad benzerliğiyle olası aynı kişiyi bulur — AI duplicate uyarısı için (Bölüm 52). */
    @Query("SELECT * FROM contacts WHERE ad LIKE '%' || :adParcasi || '%'")
    suspend fun findSimilar(adParcasi: String): List<ContactEntity>
}
