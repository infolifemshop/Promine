package com.mindai.pro.data.local.dao

import androidx.room.*
import com.mindai.pro.data.local.entities.MindMapEdgeEntity
import com.mindai.pro.data.local.entities.MindMapNodeEntity
import com.mindai.pro.data.local.entities.TaskEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    fun getAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE aiOnerisiMi = 1")
    fun getBekleyenOneriler(): Flow<List<TaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskEntity): Long

    @Delete
    suspend fun delete(task: TaskEntity)
}

@Dao
interface MindMapDao {
    @Query("SELECT * FROM mind_map_nodes ORDER BY createdAt DESC")
    fun getAllNodes(): Flow<List<MindMapNodeEntity>>

    @Query("SELECT * FROM mind_map_edges ORDER BY createdAt DESC")
    fun getAllEdges(): Flow<List<MindMapEdgeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNode(node: MindMapNodeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEdge(edge: MindMapEdgeEntity): Long

    @Query("DELETE FROM mind_map_nodes")
    suspend fun clearNodes()

    @Query("DELETE FROM mind_map_edges")
    suspend fun clearEdges()
}
