package com.mindai.pro.ui.navigation

sealed class Screen(val route: String) {
    data object AnaSayfa : Screen("ana_sayfa")
    data object ZihinHaritasi : Screen("zihin_haritasi")
    data object Gorevler : Screen("gorevler")
    data object Cari : Screen("cari")
    data object CariDetay : Screen("cari_detay/{contactId}") {
        fun path(contactId: Long) = "cari_detay/$contactId"
    }
    data object DahaFazla : Screen("daha_fazla")
    data object AiGiris : Screen("ai_giris")
    data object AiSonuc : Screen("ai_sonuc")
    data object Ayarlar : Screen("ayarlar")
    data object Cekler : Screen("cekler")
    data object Senetler : Screen("senetler")
    data object Bankalar : Screen("bankalar")
    data object Kasa : Screen("kasa")
    data object Faturalar : Screen("faturalar")
    data object Stoklar : Screen("stoklar")
}
