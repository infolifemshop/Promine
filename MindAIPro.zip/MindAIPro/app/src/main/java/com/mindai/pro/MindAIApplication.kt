package com.mindai.pro

import android.app.Application
import com.mindai.pro.data.local.AppDatabase
import com.mindai.pro.data.repository.AppRepository
import com.mindai.pro.domain.ai.AIAnalysisService
import com.mindai.pro.domain.ai.TurkishRuleBasedAnalysisService

/**
 * Basit, manuel bağımlılık enjeksiyonu (Hilt/Dagger olmadan — internet erişimi
 * gerektiren ek derleyici eklentilerinden kaçınmak için). Gerçek bir üretim
 * projesinde bu yerine Hilt kullanılabilir; yapı buna uygundur.
 */
class MindAIApplication : Application() {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val repository: AppRepository by lazy { AppRepository(database) }
    val aiService: AIAnalysisService by lazy { TurkishRuleBasedAnalysisService() }
}
