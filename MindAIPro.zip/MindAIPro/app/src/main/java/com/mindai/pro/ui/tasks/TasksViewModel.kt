package com.mindai.pro.ui.tasks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindai.pro.data.local.entities.TaskEntity
import com.mindai.pro.data.repository.AppRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class TasksViewModel(repository: AppRepository) : ViewModel() {
    val tasks: StateFlow<List<TaskEntity>> = repository.tasks()
        .map { list -> list.filter { !it.aiOnerisiMi } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
