package com.mindai.pro.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.mindai.pro.data.local.entities.BankAccountEntity
import com.mindai.pro.data.local.entities.BankTransactionEntity
import com.mindai.pro.data.local.entities.CashMovementEntity
import com.mindai.pro.data.local.entities.CheckEntity
import com.mindai.pro.data.local.entities.InvoiceEntity
import com.mindai.pro.data.local.entities.PromissoryNoteEntity
import com.mindai.pro.data.local.entities.StockItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CheckDao {
    @Query("SELECT * FROM checks ORDER BY createdAt DESC")
    fun getAll(): Flow<List<CheckEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(check: CheckEntity): Long
}

@Dao
interface PromissoryNoteDao {
    @Query("SELECT * FROM promissory_notes ORDER BY createdAt DESC")
    fun getAll(): Flow<List<PromissoryNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: PromissoryNoteEntity): Long
}

@Dao
interface BankDao {
    @Query("SELECT * FROM bank_accounts ORDER BY bankaAdi ASC")
    fun getAllAccounts(): Flow<List<BankAccountEntity>>

    @Query("SELECT * FROM bank_transactions ORDER BY createdAt DESC")
    fun getAllTransactions(): Flow<List<BankTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAccount(account: BankAccountEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTransaction(tx: BankTransactionEntity): Long

    @Query("UPDATE bank_accounts SET bakiye = bakiye + :delta WHERE id = :accountId")
    suspend fun adjustBalance(accountId: Long, delta: Double)
}

@Dao
interface CashDao {
    @Query("SELECT * FROM cash_movements ORDER BY createdAt DESC")
    fun getAll(): Flow<List<CashMovementEntity>>

    @Query("SELECT COALESCE(SUM(CASE WHEN yon = 'GIRIS' THEN tutar ELSE -tutar END), 0) FROM cash_movements")
    fun bakiye(): Flow<Double>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(movement: CashMovementEntity): Long
}

@Dao
interface InvoiceDao {
    @Query("SELECT * FROM invoices ORDER BY createdAt DESC")
    fun getAll(): Flow<List<InvoiceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(invoice: InvoiceEntity): Long
}

@Dao
interface StockDao {
    @Query("SELECT * FROM stock_items ORDER BY urunAdi ASC")
    fun getAll(): Flow<List<StockItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: StockItemEntity): Long
}
