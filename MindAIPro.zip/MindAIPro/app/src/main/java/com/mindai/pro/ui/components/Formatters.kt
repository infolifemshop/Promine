package com.mindai.pro.ui.components

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val turkishLocale = Locale("tr", "TR")

/** 250.000 TL biçiminde gösterir — Bölüm 20/21. */
fun formatTl(amount: Double): String {
    val format = NumberFormat.getNumberInstance(turkishLocale)
    format.maximumFractionDigits = 0
    return "${format.format(amount)} TL"
}

/** 16.08.2026 biçiminde gösterir — Bölüm 22. */
fun formatDate(millis: Long): String =
    SimpleDateFormat("dd.MM.yyyy", turkishLocale).format(Date(millis))
