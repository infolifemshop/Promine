package com.mindai.pro.ui.contacts

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mindai.pro.R
import com.mindai.pro.ui.components.formatTl
import com.mindai.pro.ui.theme.MindGreen
import com.mindai.pro.ui.theme.MindRed

@Composable
fun ContactsScreen(viewModel: ContactsViewModel) {
    val contacts by viewModel.contacts.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.cari_hesaplar), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))

        if (contacts.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.bos_kisi_yok))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(contacts, key = { it.contact.id }) { item ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(item.contact.ad, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            item.contact.firma?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Column {
                                    Text(stringResource(R.string.cari_alacak), style = MaterialTheme.typography.labelSmall)
                                    Text(formatTl(item.alacak), color = MindGreen, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text(stringResource(R.string.cari_borc), style = MaterialTheme.typography.labelSmall)
                                    Text(formatTl(item.borc), color = MindRed, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
