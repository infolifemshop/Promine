package com.mindai.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.mindai.pro.ui.navigation.MindAINavGraph
import com.mindai.pro.ui.theme.MindAIProTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as MindAIApplication

        setContent {
            MindAIProTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MindAINavGraph(app = app)
                }
            }
        }
    }
}
