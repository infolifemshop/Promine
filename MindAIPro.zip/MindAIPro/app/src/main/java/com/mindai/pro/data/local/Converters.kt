package com.mindai.pro.data.local

import androidx.room.TypeConverter
import com.mindai.pro.domain.model.*

class Converters {
    @TypeConverter fun fromRecordStatus(v: RecordStatus): String = v.name
    @TypeConverter fun toRecordStatus(v: String): RecordStatus = RecordStatus.valueOf(v)

    @TypeConverter fun fromContactType(v: ContactType): String = v.name
    @TypeConverter fun toContactType(v: String): ContactType = ContactType.valueOf(v)

    @TypeConverter fun fromFinancialRecordType(v: FinancialRecordType): String = v.name
    @TypeConverter fun toFinancialRecordType(v: String): FinancialRecordType = FinancialRecordType.valueOf(v)

    @TypeConverter fun fromTaskPriority(v: TaskPriority): String = v.name
    @TypeConverter fun toTaskPriority(v: String): TaskPriority = TaskPriority.valueOf(v)

    @TypeConverter fun fromTaskStatus(v: TaskStatus): String = v.name
    @TypeConverter fun toTaskStatus(v: String): TaskStatus = TaskStatus.valueOf(v)

    @TypeConverter fun fromNodeType(v: NodeType): String = v.name
    @TypeConverter fun toNodeType(v: String): NodeType = NodeType.valueOf(v)

    @TypeConverter fun fromCheckStatus(v: CheckStatus): String = v.name
    @TypeConverter fun toCheckStatus(v: String): CheckStatus = CheckStatus.valueOf(v)

    @TypeConverter fun fromNoteStatus(v: NoteStatus): String = v.name
    @TypeConverter fun toNoteStatus(v: String): NoteStatus = NoteStatus.valueOf(v)

    @TypeConverter fun fromInvoiceStatus(v: InvoiceStatus): String = v.name
    @TypeConverter fun toInvoiceStatus(v: String): InvoiceStatus = InvoiceStatus.valueOf(v)

    @TypeConverter fun fromMovementDirection(v: MovementDirection): String = v.name
    @TypeConverter fun toMovementDirection(v: String): MovementDirection = MovementDirection.valueOf(v)
}
