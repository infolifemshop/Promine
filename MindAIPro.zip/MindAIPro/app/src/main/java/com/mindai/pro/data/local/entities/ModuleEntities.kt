package com.mindai.pro.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mindai.pro.domain.model.CheckStatus
import com.mindai.pro.domain.model.InvoiceStatus
import com.mindai.pro.domain.model.MovementDirection
import com.mindai.pro.domain.model.NoteStatus

/** Çek — Bölüm 14. */
@Entity(tableName = "checks")
data class CheckEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kisiAdi: String,
    val bankaAdi: String? = null,
    val tutar: Double,
    val vadeTarihi: Long? = null,
    val alinanCek: Boolean = true, // true: alınan çek, false: verilen çek
    val durum: CheckStatus = CheckStatus.BEKLENIYOR,
    val createdAt: Long = System.currentTimeMillis()
)

/** Senet — Bölüm 15. */
@Entity(tableName = "promissory_notes")
data class PromissoryNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kisiAdi: String,
    val tutar: Double,
    val vadeTarihi: Long? = null,
    val alinanSenet: Boolean = true,
    val durum: NoteStatus = NoteStatus.BEKLENIYOR,
    val createdAt: Long = System.currentTimeMillis()
)

/** Banka hesabı — Bölüm 16. */
@Entity(tableName = "bank_accounts")
data class BankAccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bankaAdi: String,
    val bakiye: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

/** Banka hesap hareketi. */
@Entity(tableName = "bank_transactions")
data class BankTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bankAccountId: Long,
    val tutar: Double,
    val yon: MovementDirection,
    val aciklama: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/** Kasa hareketi — Bölüm 17 (tek kasa varsayımı). */
@Entity(tableName = "cash_movements")
data class CashMovementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tutar: Double,
    val yon: MovementDirection,
    val aciklama: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/** Fatura — Bölüm 19. */
@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val faturaNo: String,
    val contactAdi: String,
    val tutar: Double,
    val kdvOrani: Double? = null,
    val vadeTarihi: Long? = null,
    val durum: InvoiceStatus = InvoiceStatus.TASLAK,
    val createdAt: Long = System.currentTimeMillis()
)

/** Stok kartı — Bölüm 22. */
@Entity(tableName = "stock_items")
data class StockItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val urunAdi: String,
    val birim: String? = null,
    val alisFiyati: Double? = null,
    val satisFiyati: Double? = null,
    val mevcutStok: Double = 0.0,
    val minimumStok: Double? = null,
    val createdAt: Long = System.currentTimeMillis()
)
