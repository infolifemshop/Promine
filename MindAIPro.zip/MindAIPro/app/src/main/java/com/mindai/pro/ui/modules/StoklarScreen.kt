package com.mindai.pro.ui.modules

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindai.pro.R
import com.mindai.pro.data.local.entities.StockItemEntity
import com.mindai.pro.data.repository.AppRepository
import com.mindai.pro.ui.components.formatTl
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StokViewModel(private val repository: AppRepository) : ViewModel() {
    val items: StateFlow<List<StockItemEntity>> =
        repository.stockItems().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun ekle(urunAdi: String, birim: String?, mevcutStok: Double) = viewModelScope.launch {
        repository.upsertStockItem(StockItemEntity(urunAdi = urunAdi, birim = birim, mevcutStok = mevcutStok))
    }
}

@Composable
fun StoklarScreen(viewModel: StokViewModel) {
    val stokKalemleri by viewModel.items.collectAsState()
    var dialogAcik by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { dialogAcik = true }) { Icon(Icons.Filled.Add, contentDescription = null) }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(stringResource(R.string.menu_stoklar), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            if (stokKalemleri.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.bos_kayit_yok))
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(stokKalemleri, key = { it.id }) { item ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(item.urunAdi, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "${stringResource(R.string.alan_stok_miktari)}: ${item.mevcutStok} ${item.birim ?: ""}".trim(),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (dialogAcik) {
        var urunAdi by remember { mutableStateOf("") }
        var birim by remember { mutableStateOf("") }
        var stok by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { dialogAcik = false },
            title = { Text(stringResource(R.string.btn_yeni_kayit_ekle)) },
            text = {
                Column {
                    OutlinedTextField(urunAdi, { urunAdi = it }, label = { Text(stringResource(R.string.alan_urun_adi)) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(birim, { birim = it }, label = { Text(stringResource(R.string.alan_birim)) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(stok, { stok = it }, label = { Text(stringResource(R.string.alan_stok_miktari)) }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val s = stok.replace(",", ".").toDoubleOrNull() ?: 0.0
                    if (urunAdi.isNotBlank()) {
                        viewModel.ekle(urunAdi, birim.ifBlank { null }, s)
                        dialogAcik = false
                    }
                }) { Text(stringResource(R.string.btn_olustur)) }
            },
            dismissButton = {
                TextButton(onClick = { dialogAcik = false }) { Text(stringResource(R.string.btn_iptal)) }
            }
        )
    }
}
