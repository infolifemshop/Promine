package com.mindai.pro.ui.modules

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindai.pro.R
import com.mindai.pro.data.local.entities.CashMovementEntity
import com.mindai.pro.data.repository.AppRepository
import com.mindai.pro.domain.model.MovementDirection
import com.mindai.pro.ui.components.formatTl
import com.mindai.pro.ui.theme.MindGreen
import com.mindai.pro.ui.theme.MindRed
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class KasaViewModel(private val repository: AppRepository) : ViewModel() {
    val movements: StateFlow<List<CashMovementEntity>> =
        repository.cashMovements().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val bakiye: StateFlow<Double> =
        repository.kasaBakiyesi().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun ekle(tutar: Double, yon: MovementDirection, aciklama: String?) = viewModelScope.launch {
        repository.addCashMovement(CashMovementEntity(tutar = tutar, yon = yon, aciklama = aciklama))
    }
}

@Composable
fun KasaScreen(viewModel: KasaViewModel) {
    val movements by viewModel.movements.collectAsState()
    val bakiye by viewModel.bakiye.collectAsState()
    var dialogAcik by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { dialogAcik = true }) { Icon(Icons.Filled.Add, contentDescription = null) }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(stringResource(R.string.menu_kasa), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(stringResource(R.string.kart_kasa), style = MaterialTheme.typography.bodyMedium)
                    Text(formatTl(bakiye), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(12.dp))

            if (movements.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.bos_islem_yok))
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(movements, key = { it.id }) { movement ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.padding(14.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(movement.aciklama ?: stringResource(movement.yon.label), style = MaterialTheme.typography.bodyLarge)
                                    Text(stringResource(movement.yon.label), style = MaterialTheme.typography.labelSmall)
                                }
                                val renk = if (movement.yon == MovementDirection.GIRIS) MindGreen else MindRed
                                Text(formatTl(movement.tutar), color = renk, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (dialogAcik) {
        var tutar by remember { mutableStateOf("") }
        var aciklama by remember { mutableStateOf("") }
        var girisSecili by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { dialogAcik = false },
            title = { Text(stringResource(R.string.btn_yeni_kayit_ekle)) },
            text = {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = girisSecili, onClick = { girisSecili = true }, label = { Text(stringResource(R.string.hareket_giris)) })
                        FilterChip(selected = !girisSecili, onClick = { girisSecili = false }, label = { Text(stringResource(R.string.hareket_cikis)) })
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(tutar, { tutar = it }, label = { Text(stringResource(R.string.alan_tutar)) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(aciklama, { aciklama = it }, label = { Text(stringResource(R.string.alan_aciklama)) }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = tutar.replace(",", ".").toDoubleOrNull()
                    if (t != null) {
                        viewModel.ekle(t, if (girisSecili) MovementDirection.GIRIS else MovementDirection.CIKIS, aciklama.ifBlank { null })
                        dialogAcik = false
                    }
                }) { Text(stringResource(R.string.btn_olustur)) }
            },
            dismissButton = {
                TextButton(onClick = { dialogAcik = false }) { Text(stringResource(R.string.btn_iptal)) }
            }
        )
    }
}
