package com.mindai.pro.ui.contacts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindai.pro.data.local.entities.ContactEntity
import com.mindai.pro.data.local.entities.FinancialRecordEntity
import com.mindai.pro.data.repository.AppRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class ContactWithBalance(
    val contact: ContactEntity,
    val alacak: Double,
    val borc: Double
)

class ContactsViewModel(private val repository: AppRepository) : ViewModel() {

    val contacts: StateFlow<List<ContactWithBalance>> = combine(
        repository.contacts(), repository.financialRecords()
    ) { contacts, records ->
        // Not: aiTarafindanMi yalnızca izlenebilirlik amaçlıdır (Bölüm 52) — burada
        // filtrelenmez, çünkü bu cari kayıtlar zaten kullanıcının bir AI önerisini
        // onaylamasıyla (bkz. AppRepository.resolveOrCreateContact) oluşturulmuştur.
        contacts.map { c ->
            val recs = records.filter { it.contactId == c.id && !it.aiOnerisiMi }
            ContactWithBalance(
                contact = c,
                alacak = recs.filter { it.tur == com.mindai.pro.domain.model.FinancialRecordType.TAHSILAT }.sumOf { it.tutar },
                borc = recs.filter { it.tur == com.mindai.pro.domain.model.FinancialRecordType.ODEME }.sumOf { it.tutar }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
