package com.mindai.pro.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mindai.pro.domain.model.FinancialRecordType
import com.mindai.pro.domain.model.RecordStatus

/**
 * Gelir, Gider, Tahsilat ve Ödeme tek tabloda; `tur` alanı ile ayrışır.
 * Bkz. Bölüm 9-10. Çek/Senet ile ödeme yöntemi metinsel olarak tutulur (odemeYontemi).
 */
@Entity(tableName = "financial_records")
data class FinancialRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tur: FinancialRecordType,
    val contactId: Long?,
    val contactAdiGecici: String? = null, // AI önerisi henüz onaylı cari'ye bağlanmadıysa
    val aciklama: String,
    val kategori: String? = null,
    val tutar: Double,
    val kdvOrani: Double? = null, // null = "KDV belirtilmedi" (Bölüm 12)
    val odemeYontemi: String? = null,
    val vadeTarihi: Long? = null,
    val durum: RecordStatus,
    val kaynakMetin: String? = null, // AI'nin ürettiği kayıtlarda orijinal cümle (izlenebilirlik)
    val aiOnerisiMi: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
