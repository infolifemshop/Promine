package com.mindai.pro.ui.ai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindai.pro.data.local.entities.FinancialRecordEntity
import com.mindai.pro.data.local.entities.TaskEntity
import com.mindai.pro.data.repository.AppRepository
import com.mindai.pro.domain.ai.AIAnalysisService
import com.mindai.pro.domain.ai.AnalysisResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface AiUiState {
    data object Bos : AiUiState
    data class Analiz(val adimIndex: Int) : AiUiState
    data class Sonuc(val result: AnalysisResult) : AiUiState
    data class Hata(val mesajResId: Int) : AiUiState
}

/**
 * Ekranlar arasında paylaşılan (activity-scoped) ViewModel: AI Giriş ekranında
 * üretilen analiz sonucu, Sonuç ekranına navigasyon argümanı olarak taşınmak
 * yerine bu ortak state üzerinden okunur.
 */
class AiSharedViewModel(
    private val aiService: AIAnalysisService,
    private val repository: AppRepository
) : ViewModel() {

    private val _state = MutableStateFlow<AiUiState>(AiUiState.Bos)
    val state: StateFlow<AiUiState> = _state.asStateFlow()

    fun analyze(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            for (i in 0..8) {
                _state.value = AiUiState.Analiz(i)
                kotlinx.coroutines.delay(180)
            }
            val result = aiService.analyze(text)
            repository.persistAsSuggestions(result)
            _state.value = AiUiState.Sonuc(result)
        }
    }

    fun reset() {
        _state.value = AiUiState.Bos
    }

    val bekleyenFinansalOneriler: StateFlow<List<FinancialRecordEntity>> =
        repository.pendingAiSuggestions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onaylaKayit(record: FinancialRecordEntity) = viewModelScope.launch {
        // Cari isim varsa eşleştir/oluştur, ardından kaydı kesinleştir (Bölüm 6/25).
        val contactId = record.contactAdiGecici?.let { repository.resolveOrCreateContact(it) }
        repository.approveRecord(record.copy(contactId = contactId ?: record.contactId))
    }

    fun reddetKayit(record: FinancialRecordEntity) = viewModelScope.launch {
        repository.rejectRecord(record)
    }

    fun onaylaGorev(task: TaskEntity) = viewModelScope.launch { repository.approveTask(task) }
    fun reddetGorev(task: TaskEntity) = viewModelScope.launch { repository.rejectTask(task) }
}
