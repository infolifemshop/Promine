package com.mindai.pro.domain.ai

/**
 * AI Service arayüzü. Tek görevi kullanıcı metnini analiz etmek ve STRICT JSON
 * (AnalysisResult) döndürmektir (Bölüm 22/72).
 *
 * Bu proje çevrimdışı/yerel bir referans uygulama olarak, gerçek bir LLM API
 * çağrısı yerine [TurkishRuleBasedAnalysisService] kullanır. Üretimde bu arayüzün
 * arkasına Anthropic API (veya benzeri) çağıran bir implementasyon eklenebilir;
 * geri kalan uygulama (UI, Repository, Room) hiç değişmeden çalışmaya devam eder.
 */
interface AIAnalysisService {
    suspend fun analyze(userText: String): AnalysisResult
}
