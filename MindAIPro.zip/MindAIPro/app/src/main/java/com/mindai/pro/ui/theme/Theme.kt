package com.mindai.pro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = MindBlue,
    secondary = MindAiAccent,
    background = MindBackground,
    surface = MindCard,
    error = MindRed
)

private val DarkColors = darkColorScheme(
    primary = MindAiAccent,
    secondary = MindBlue,
    background = MindPrimaryDark,
    surface = Color(0xFF11213D),
    error = MindRed
)

@Composable
fun MindAIProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = MindAITypography,
        content = content
    )
}
