package com.mindai.pro.data.local.dao

import androidx.room.*
import com.mindai.pro.data.local.entities.FinancialRecordEntity
import com.mindai.pro.domain.model.FinancialRecordType
import com.mindai.pro.domain.model.RecordStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface FinancialRecordDao {
    @Query("SELECT * FROM financial_records ORDER BY createdAt DESC")
    fun getAll(): Flow<List<FinancialRecordEntity>>

    @Query("SELECT * FROM financial_records WHERE tur = :tur ORDER BY createdAt DESC")
    fun getByType(tur: FinancialRecordType): Flow<List<FinancialRecordEntity>>

    @Query("SELECT * FROM financial_records WHERE contactId = :contactId ORDER BY createdAt DESC")
    fun getByContact(contactId: Long): Flow<List<FinancialRecordEntity>>

    @Query("SELECT * FROM financial_records WHERE aiOnerisiMi = 1 AND durum = 'UNCERTAIN'")
    fun getBekleyenOneriler(): Flow<List<FinancialRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: FinancialRecordEntity): Long

    @Delete
    suspend fun delete(record: FinancialRecordEntity)

    // Dashboard toplamları — yalnızca kesinleşmiş/onaylanmış kayıtlardan hesaplanır (Bölüm 5).
    @Query("SELECT COALESCE(SUM(tutar),0) FROM financial_records WHERE tur = 'TAHSILAT' AND durum IN ('EXPECTED','CONFIRMED') AND aiOnerisiMi = 0")
    fun toplamAlacak(): Flow<Double>

    @Query("SELECT COALESCE(SUM(tutar),0) FROM financial_records WHERE tur = 'ODEME' AND durum IN ('EXPECTED','CONFIRMED') AND aiOnerisiMi = 0")
    fun toplamBorc(): Flow<Double>

    @Query("SELECT COALESCE(SUM(tutar),0) FROM financial_records WHERE tur = 'TAHSILAT' AND durum = 'COMPLETED' AND createdAt >= :gunBaslangici")
    fun bugunTahsilat(gunBaslangici: Long): Flow<Double>

    @Query("SELECT COALESCE(SUM(tutar),0) FROM financial_records WHERE tur = 'ODEME' AND durum = 'COMPLETED' AND createdAt >= :gunBaslangici")
    fun bugunOdeme(gunBaslangici: Long): Flow<Double>

    @Query("SELECT * FROM financial_records WHERE durum IN ('EXPECTED') AND vadeTarihi IS NOT NULL AND vadeTarihi < :simdi AND aiOnerisiMi = 0")
    fun gecikenler(simdi: Long): Flow<List<FinancialRecordEntity>>
}
