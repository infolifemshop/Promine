package com.mindai.pro.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import com.mindai.pro.MindAIApplication
import com.mindai.pro.ui.ai.AiSharedViewModel
import com.mindai.pro.ui.contacts.ContactsViewModel
import com.mindai.pro.ui.dashboard.DashboardViewModel
import com.mindai.pro.ui.mindmap.MindMapViewModel
import com.mindai.pro.ui.modules.BankaViewModel
import com.mindai.pro.ui.modules.CekViewModel
import com.mindai.pro.ui.modules.FaturaViewModel
import com.mindai.pro.ui.modules.KasaViewModel
import com.mindai.pro.ui.modules.SenetViewModel
import com.mindai.pro.ui.modules.StokViewModel
import com.mindai.pro.ui.tasks.TasksViewModel

/** Hilt olmadan manuel DI: her ViewModel'in Application'daki tekil bağımlılıkları kullanmasını sağlar. */
class MindAIViewModelFactory(private val app: MindAIApplication) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
        return when (modelClass) {
            DashboardViewModel::class.java -> DashboardViewModel(app.repository) as T
            AiSharedViewModel::class.java -> AiSharedViewModel(app.aiService, app.repository) as T
            MindMapViewModel::class.java -> MindMapViewModel(app.repository) as T
            ContactsViewModel::class.java -> ContactsViewModel(app.repository) as T
            TasksViewModel::class.java -> TasksViewModel(app.repository) as T
            CekViewModel::class.java -> CekViewModel(app.repository) as T
            SenetViewModel::class.java -> SenetViewModel(app.repository) as T
            BankaViewModel::class.java -> BankaViewModel(app.repository) as T
            KasaViewModel::class.java -> KasaViewModel(app.repository) as T
            FaturaViewModel::class.java -> FaturaViewModel(app.repository) as T
            StokViewModel::class.java -> StokViewModel(app.repository) as T
            else -> throw IllegalArgumentException("Bilinmeyen ViewModel: ${modelClass.name}")
        }
    }
}
