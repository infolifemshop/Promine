package com.mindai.pro.domain.ai

import com.mindai.pro.domain.model.FinancialRecordType
import com.mindai.pro.domain.model.RecordStatus
import com.mindai.pro.domain.model.TaskPriority
import kotlinx.coroutines.delay

/**
 * Yerel, kural tabanlı Türkçe metin analiz servisi.
 *
 * Bu, gerçek bir büyük dil modeli API'sinin yerine geçmez; [AIAnalysisService]
 * arayüzünün internet erişimi olmadan da çalışan, açıklanabilir bir referans
 * uygulamasıdır. Amaç: uçtan uca boru hattını (anlatım → öneri kartı → onay →
 * muhasebe kaydı + zihin haritası) gerçek veriyle göstermek.
 *
 * Üretimde bu sınıfın yerine `AIAnalysisService`'i implement eden, gerçek bir
 * API çağrısı yapan bir sınıf (örn. AnthropicAnalysisService) enjekte edilir;
 * geri kalan hiçbir kod değişmez.
 */
class TurkishRuleBasedAnalysisService : AIAnalysisService {

    private val moneyWithSuffixRegex = Regex("""(\d+)\s*(bin|milyon|milyar)""", RegexOption.IGNORE_CASE)

    private val completedKeywords = listOf("aldım", "gönderdi", "geldi", "teslim edildi", "tamamlandı", "ödedi", "yaptım")
    private val uncertainKeywords = listOf("belki", "galiba", "sanırım", "olabilir")
    private val taskKeywords = listOf("takip etmeliyim", "almam lazım", "bulmalıyım", "bakmalıyım", "araştırmalıyım", "göndermem lazım", "vermesi lazım", "çalıştırmalıyım")

    override suspend fun analyze(userText: String): AnalysisResult {
        // Gerçekçi bir "analiz ediliyor" hissi için küçük bir gecikme (adım mesajları UI tarafında gösterilir).
        delay(300)

        val sentences = userText.split(Regex("[.\n]")).map { it.trim() }.filter { it.isNotBlank() }

        val entities = mutableListOf<ExtractedEntity>()
        val relationships = mutableListOf<ExtractedRelationship>()
        val financialRecords = mutableListOf<ExtractedFinancialRecord>()
        val tasks = mutableListOf<ExtractedTask>()

        var entityCounter = 0
        fun newId(): String = "e${entityCounter++}"

        for (sentence in sentences) {
            val personName = extractPersonName(sentence)
            val amount = extractAmount(sentence)
            val status = extractStatus(sentence)
            val recordType = inferRecordType(sentence)

            val personId = personName?.let { name ->
                val id = newId()
                entities += ExtractedEntity(id, "KISI", name, confidence = 0.7, sourceText = sentence)
                id
            }
            val moneyId = amount?.let { amt ->
                val id = newId()
                entities += ExtractedEntity(id, "PARA", formatTl(amt), confidence = 0.8, sourceText = sentence)
                id
            }

            if (personId != null && moneyId != null) {
                relationships += ExtractedRelationship(
                    fromLocalId = personId,
                    toLocalId = moneyId,
                    label = if (recordType == FinancialRecordType.TAHSILAT) "Ödeme alacak" else "Ödeme yapacak",
                    confidence = 0.6
                )
            }

            if (amount != null && recordType != null) {
                financialRecords += ExtractedFinancialRecord(
                    type = recordType,
                    contactName = personName,
                    description = sentence.take(60),
                    amount = amount,
                    status = status,
                    dueDateLabel = extractDateHint(sentence),
                    sourceText = sentence
                )
            }

            if (taskKeywords.any { sentence.contains(it, ignoreCase = true) }) {
                tasks += ExtractedTask(
                    title = sentence.replaceFirstChar { it.uppercase() },
                    relatedContactName = personName,
                    priority = if (sentence.contains("çek", ignoreCase = true)) TaskPriority.KRITIK else TaskPriority.ORTA,
                    sourceText = sentence
                )
            }
        }

        return AnalysisResult(
            title = "Yapay Zekâ Analizi",
            summary = "Anlatımınızda ${entities.count { it.type == "KISI" }} kişi, " +
                "${financialRecords.size} para hareketi, ${tasks.size} görev tespit edildi.",
            entities = entities,
            relationships = relationships,
            financialRecords = financialRecords,
            tasks = tasks
        )
    }

    private fun extractPersonName(sentence: String): String? {
        // "İsa abi", "Salih abiye", "Zekeriyya abid" gibi "abi/abla" ekli isimleri yakalar.
        val abiMatch = Regex("""([A-ZÇĞİÖŞÜ][a-zçğıöşü]+)\s+abi\w*""", RegexOption.IGNORE_CASE).find(sentence)
        if (abiMatch != null) return "${abiMatch.groupValues[1].replaceFirstChar { it.uppercase() }} Abi"

        // Büyük harfle başlayan, cümle başı olmayan bağımsız özel isim adayı (örn. "Özer", "Mehmet").
        // "Mehmet'ten", "Ali'ye" gibi kesme işaretli hal eklerini isimden ayıklar.
        val words = sentence.split(" ")
        for ((idx, w) in words.withIndex()) {
            val trimmed = w.trim(',', '.', ':', ';', '!', '?')
            val beforeApostrophe = trimmed.substringBefore('\'')
            if (beforeApostrophe.length > 2 && beforeApostrophe[0].isUpperCase() && idx != 0 &&
                beforeApostrophe.none { it.isDigit() }
            ) {
                return beforeApostrophe
            }
        }
        return null
    }

    private fun extractAmount(sentence: String): Double? {
        // 1) "100 bin", "13 milyon" gibi ölçek ekli sayılar.
        moneyWithSuffixRegex.find(sentence)?.let { m ->
            val base = m.groupValues[1].replace(",", ".").toDoubleOrNull()
            if (base != null) {
                val mult = when (m.groupValues[2].lowercase()) {
                    "bin" -> 1_000.0
                    "milyon" -> 1_000_000.0
                    "milyar" -> 1_000_000_000.0
                    else -> 1.0
                }
                return base * mult
            }
        }
        // 2) "250.000" / "250,000" gibi binlik ayraçlı sayılar.
        Regex("""\d{1,3}(?:[.,]\d{3})+""").find(sentence)?.let { m ->
            val normalized = m.value.replace(".", "").replace(",", "")
            normalized.toDoubleOrNull()?.let { return it }
        }
        // 3) "500 TL", "5000 lira", "80TL" gibi ayraçsız düz rakam + para birimi ifadeleri.
        Regex("""(\d+(?:[.,]\d+)?)\s*(?:tl|try|₺|lira)""", RegexOption.IGNORE_CASE).find(sentence)?.let { m ->
            m.groupValues[1].replace(",", ".").toDoubleOrNull()?.let { return it }
        }
        // 4) Yazıyla yazılmış Türkçe sayılar ("iki yüz elli bin").
        TurkishNumberParser.findWrittenAmounts(sentence).firstOrNull()?.let { return it.second }
        return null
    }

    private fun extractStatus(sentence: String): RecordStatus = when {
        uncertainKeywords.any { sentence.contains(it, ignoreCase = true) } -> RecordStatus.UNCERTAIN
        completedKeywords.any { sentence.contains(it, ignoreCase = true) } -> RecordStatus.COMPLETED
        else -> RecordStatus.EXPECTED
    }

    private fun inferRecordType(sentence: String): FinancialRecordType? {
        val s = sentence.lowercase()
        return when {
            "borcum var" in s || "ödeme vermesi" in s || "peşinat" in s || "göndermem" in s -> FinancialRecordType.ODEME
            "borcu var" in s || "aldım" in s || "alacağım" in s || "tahsilat" in s -> FinancialRecordType.TAHSILAT
            "fatura" in s && "geldi" in s -> FinancialRecordType.GIDER
            "sattı" in s || "satış" in s || "gelir" in s -> FinancialRecordType.GELIR
            Regex("""\d""").containsMatchIn(s) || TurkishNumberParser.findWrittenAmounts(s).isNotEmpty() -> FinancialRecordType.TAHSILAT
            else -> null
        }
    }

    private fun extractDateHint(sentence: String): String? {
        val hints = listOf("yarın", "öbür gün", "haftaya", "gelecek cuma", "bu hafta", "gelecek ay", "ayın sonunda")
        return hints.firstOrNull { sentence.contains(it, ignoreCase = true) }
    }

    private fun formatTl(amount: Double): String {
        val whole = amount.toLong()
        val formatted = whole.toString().reversed().chunked(3).joinToString(".").reversed()
        return "$formatted TL"
    }
}
