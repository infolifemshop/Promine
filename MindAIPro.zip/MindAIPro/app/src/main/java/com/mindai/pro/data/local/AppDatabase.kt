package com.mindai.pro.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.mindai.pro.data.local.dao.BankDao
import com.mindai.pro.data.local.dao.CashDao
import com.mindai.pro.data.local.dao.CheckDao
import com.mindai.pro.data.local.dao.ContactDao
import com.mindai.pro.data.local.dao.FinancialRecordDao
import com.mindai.pro.data.local.dao.InvoiceDao
import com.mindai.pro.data.local.dao.MindMapDao
import com.mindai.pro.data.local.dao.PromissoryNoteDao
import com.mindai.pro.data.local.dao.StockDao
import com.mindai.pro.data.local.dao.TaskDao
import com.mindai.pro.data.local.entities.BankAccountEntity
import com.mindai.pro.data.local.entities.BankTransactionEntity
import com.mindai.pro.data.local.entities.CashMovementEntity
import com.mindai.pro.data.local.entities.CheckEntity
import com.mindai.pro.data.local.entities.ContactEntity
import com.mindai.pro.data.local.entities.FinancialRecordEntity
import com.mindai.pro.data.local.entities.InvoiceEntity
import com.mindai.pro.data.local.entities.MindMapEdgeEntity
import com.mindai.pro.data.local.entities.MindMapNodeEntity
import com.mindai.pro.data.local.entities.PromissoryNoteEntity
import com.mindai.pro.data.local.entities.StockItemEntity
import com.mindai.pro.data.local.entities.TaskEntity

/**
 * Uygulamanın tek yerel veri kaynağı. İleride çoklu işletme desteği (Bölüm 20) ve
 * cloud sync eklenebilecek şekilde repository katmanı arkasında soyutlanır.
 */
@Database(
    entities = [
        ContactEntity::class,
        FinancialRecordEntity::class,
        TaskEntity::class,
        MindMapNodeEntity::class,
        MindMapEdgeEntity::class,
        CheckEntity::class,
        PromissoryNoteEntity::class,
        BankAccountEntity::class,
        BankTransactionEntity::class,
        CashMovementEntity::class,
        InvoiceEntity::class,
        StockItemEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun financialRecordDao(): FinancialRecordDao
    abstract fun taskDao(): TaskDao
    abstract fun mindMapDao(): MindMapDao
    abstract fun checkDao(): CheckDao
    abstract fun promissoryNoteDao(): PromissoryNoteDao
    abstract fun bankDao(): BankDao
    abstract fun cashDao(): CashDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun stockDao(): StockDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mindai_pro.db"
                ).build().also { INSTANCE = it }
            }
    }
}
